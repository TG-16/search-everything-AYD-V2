// middlewares/monitorMiddleware.js
const { queueLog } = require("../utils/logQueue");

const monitorMiddleware = (req, res, next) => {
  const start = process.hrtime();

  // Listen for the request completion event
  res.on('finish', () => {
    const diff = process.hrtime(start);
    const durationInMs = parseFloat((diff[0] * 1e3 + diff[1] * 1e-6).toFixed(2));

    // 1. Dynamic extraction across request flows (JWT, API Keys, or body inputs)
    const user_id = req.user && req.user.id ? req.user.id : null;
    
    // Check where workspaceId might live based on different route designs
    const workspace_id = req.body?.workspaceId || req.query?.workspaceId || req.params?.workspaceId || null;

    // 2. Classify your event categories systematically based on URL structure or HTTP state
    let event_type = 'API_REQUEST';
    if (req.originalUrl.includes('/search')) {
      event_type = 'HYBRID_SEARCH';
    } else if (res.statusCode === 401 || res.statusCode === 403) {
      event_type = 'SECURITY_AUTH_FAILURE';
    } else if (req.method === 'DELETE') {
      event_type = 'DATA_DELETION';
    } else if (req.method === 'POST') {
      event_type = 'DATA_CREATION';
    }

    // 3. Capture the incoming client IP safely behind cloud proxies
    const ip_address = req.headers['x-forwarded-for'] || req.socket.remoteAddress || null;

    // 4. Populate dynamic telemetry payload
    const logData = {
      workspace_id,
      user_id,
      event_type,
      endpoint: req.originalUrl,
      status_code: res.statusCode,
      duration_ms: durationInMs,
      ip_address,
      meta_data: {
        method: req.method,
        rate_limited: res.statusCode === 429,
        row_count: res.locals?.rowCount || 0 // Set this in controllers if querying/modifying datasets
      }
    };

    // Queue the log asynchronously into memory instantly
    queueLog(logData);
  });

  next();
};

module.exports = monitorMiddleware;